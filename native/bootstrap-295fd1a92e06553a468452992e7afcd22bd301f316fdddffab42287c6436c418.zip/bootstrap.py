"""First boot of a native template. Secrets are created inside the partner account.

Private object storage is the checkpoint, including across VM replacement. Never
write generated credentials into template outputs, instance metadata or logs.
"""
import base64, hashlib, json, os, pathlib, secrets, subprocess, sys, tarfile, urllib.request, uuid

CONTROL = 'https://trulyyou-control.slick-run.workers.dev'

class Store:
    def __init__(self, config):
        self.provider, self.bucket = config['provider'], config['bucket']
        if self.provider == 'aws':
            import boto3
            self.client = boto3.client('s3', region_name=config['region'])
        elif self.provider == 'gcp':
            from google.cloud import storage
            self.client = storage.Client(project=config['target']).bucket(self.bucket)
        else:
            from azure.identity import ManagedIdentityCredential
            from azure.storage.blob import BlobServiceClient
            self.client = BlobServiceClient('https://' + config['account'] + '.blob.core.windows.net', credential=ManagedIdentityCredential(client_id=config['clientId'])).get_container_client(self.bucket)

    def read(self, name):
        try:
            if self.provider == 'aws': return self.client.get_object(Bucket=self.bucket, Key=name)['Body'].read()
            if self.provider == 'gcp': return self.client.blob(name).download_as_bytes()
            return self.client.download_blob(name).readall()
        except Exception as error:
            # Authorization and transport failures must never look like an empty installation.
            code = getattr(error, 'response', {}).get('Error', {}).get('Code')
            if code == 'NoSuchKey' or getattr(error, 'status_code', None) == 404 or getattr(error, 'code', None) == 404: return None
            raise

    def create(self, name, content):
        if self.provider == 'aws': self.client.put_object(Bucket=self.bucket, Key=name, Body=content, IfNoneMatch='*')
        elif self.provider == 'gcp': self.client.blob(name).upload_from_string(content, if_generation_match=0)
        else: self.client.upload_blob(name, content, overwrite=False)

    def upload_archive(self, filename):
        with open(filename, 'rb') as source:
            if self.provider == 'aws': self.client.upload_fileobj(source, self.bucket, 'bootstrap/dashboard.tar')
            elif self.provider == 'gcp': self.client.blob('bootstrap/dashboard.tar').upload_from_file(source)
            else: self.client.upload_blob('bootstrap/dashboard.tar', source, overwrite=True)

def post(route, body):
    request = urllib.request.Request(CONTROL + route, data=json.dumps(body).encode(), headers={'content-type': 'application/json'}, method='POST')
    with urllib.request.urlopen(request, timeout=60) as response: return json.load(response)

def configure(config, store, register=post):
    identity = {key: config[key] for key in ['provider', 'target', 'region', 'zone', 'domain', 'owner', 'company', 'name']}
    prior = store.read('bootstrap/environment.json')
    if prior:
        checkpoint = json.loads(store.read('bootstrap/native-registration.json'))
        if checkpoint['identity'] != identity: raise ValueError('Installation inputs changed. Restore the original inputs or create a separate installation.')
        return json.loads(prior), checkpoint
    saved = store.read('bootstrap/native-registration.json')
    if saved: checkpoint = json.loads(saved)
    else:
        checkpoint = {'identity': identity, 'installationId': str(uuid.uuid4()), 'claim': secrets.token_urlsafe(32), 'downloadClaim': secrets.token_urlsafe(32), 'encryptionKey': base64.b64encode(secrets.token_bytes(32)).decode()}
        store.create('bootstrap/native-registration.json', json.dumps(checkpoint).encode())
    if checkpoint['identity'] != identity: raise ValueError('Installation inputs changed.')
    result = register('/v1/setup/install', {'provider': config['provider'], 'company': config['company'], 'ownerEmail': config['owner'].strip().lower(), 'installationId': checkpoint['installationId'], 'claim': checkpoint['claim']})
    if result['installationId'] != checkpoint['installationId']: raise ValueError('Registration mismatch')
    cloud = {'provider': config['provider'], 'targetId': config['target'], 'region': config['region'], 'zoneId': config['zone']}
    for key in ['roleArn', 'externalId', 'tenantId']:
        if config.get(key): cloud[key] = config[key]
    bootstrap = {'ownerEmail': config['owner'], 'controlOrigin': CONTROL, 'setupToken': checkpoint['installationId'] + '.' + checkpoint['claim'], 'applicationId': 'app_dashboard_' + config['name'].removeprefix('trulyyou-'), 'cloud': cloud}
    origin = 'https://' + config['domain']
    env = {'TRULYYOU_SELF_HOSTED': 'true', 'TRULYYOU_INSTALLATION_NAME': config['name'], 'TRULYYOU_STATE_PROVIDER': config['provider'], 'TRULYYOU_STATE_BUCKET': config['bucket'], 'TRULYYOU_STATE_ENCRYPTION_KEY': checkpoint['encryptionKey'], 'TRULYYOU_DASHBOARD_IMAGE': config['image'], 'PUBLIC_DASHBOARD_ORIGIN': origin, 'PUBLIC_SDK_ORIGIN': origin, 'PUBLIC_FRAME_ORIGIN': origin, 'PUBLIC_PROOF_ORIGIN': origin, 'SEED_DEMO_APPLICATIONS': 'false', 'PORT': '4802', 'ANDROID_CERT_FINGERPRINT': '90:79:31:9D:D2:B3:8F:07:00:47:9F:C4:44:A5:F0:DE:E3:5B:71:4A:AF:06:B4:51:22:BC:F1:35:76:69:6D:B8', 'DASHBOARD_BOOTSTRAP_JSON': json.dumps(bootstrap)}
    if config['provider'] == 'aws': env.update(AWS_REGION=config['region'], TRULYYOU_PULUMI_BACKEND_URL='s3://' + config['bucket'] + '/pulumi')
    elif config['provider'] == 'gcp': env.update(GOOGLE_CLOUD_PROJECT=config['target'], TRULYYOU_PULUMI_BACKEND_URL='gs://' + config['bucket'] + '/pulumi')
    else: env.update(AZURE_CLIENT_ID=config['clientId'], AZURE_STORAGE_ACCOUNT=config['account'], TRULYYOU_STATE_ACCOUNT=config['account'], TRULYYOU_PULUMI_BACKEND_URL='azblob://' + config['bucket'] + '/pulumi')
    store.create('bootstrap/environment.json', json.dumps(env).encode())
    return env, checkpoint

def main():
    os.umask(0o077)
    config = json.loads(pathlib.Path('/opt/trulyyou/native.json').read_text())
    store = Store(config)
    env, checkpoint = configure(config, store)
    if not store.read('bootstrap/image-ready.json'):
        root = pathlib.Path('/run/trulyyou-install'); root.mkdir(mode=0o700, exist_ok=True)
        grant = post('/v1/installations/download', {'token': checkpoint['installationId'] + '.' + checkpoint['claim'], 'claim': checkpoint['downloadClaim'], 'component': 'dashboard', 'image': env['TRULYYOU_DASHBOARD_IMAGE']})
        if grant['registry'] != 'ghcr.io' or grant['image'] != env['TRULYYOU_DASHBOARD_IMAGE']: raise ValueError('Release grant mismatch')
        docker_config = root / 'config.json'
        try:
            docker_config.write_text(json.dumps({'auths': {'ghcr.io': {'registrytoken': grant['registryToken']}}}))
            with urllib.request.urlopen('https://github.com/google/go-containerregistry/releases/download/v0.22.1/go-containerregistry_Linux_x86_64.tar.gz', timeout=120) as response: content = response.read()
            if hashlib.sha256(content).hexdigest() != '0ab7a1d6932a213aed964ce97666c3077fe691c8606413674a8b3e0b9ec4cda0': raise ValueError('Image tool checksum mismatch')
            (root / 'crane.tar.gz').write_bytes(content)
            with tarfile.open(root / 'crane.tar.gz') as archive: archive.extract('crane', root, filter='data')
            subprocess.run([str(root / 'crane'), 'pull', '--platform', 'linux/amd64', grant['image'], str(root / 'dashboard.tar')], env={**os.environ, 'DOCKER_CONFIG': str(root)}, check=True, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
            store.upload_archive(root / 'dashboard.tar')
            store.create('bootstrap/image-ready.json', json.dumps({'image': grant['image']}).encode())
        finally:
            docker_config.unlink(missing_ok=True)
            (root / 'dashboard.tar').unlink(missing_ok=True)
    subprocess.run([sys.executable, '/opt/trulyyou/boot.py', config['provider'], config['bucket'], config.get('account', '-')], check=True, env={**os.environ, 'AZURE_CLIENT_ID': config.get('clientId', '')})

if __name__ == '__main__':
    try: main()
    except Exception as error:
        # Cloud-init/systemd journals are not a credential store.
        print('TrulyYou bootstrap failed (' + type(error).__name__ + '). Check cloud permissions, DNS and the private bootstrap checkpoint.', file=sys.stderr)
        sys.exit(1)
