# Runs on the customer's VM using its attached cloud identity.
import json, os, pathlib, subprocess, sys, tarfile

def archive_image_reference(archive):
    manifest = json.load(archive.extractfile('manifest.json'))
    if len(manifest) != 1 or len(manifest[0].get('RepoTags', [])) != 1:
        raise ValueError('Expected one tagged dashboard image in the release archive')
    # Docker's classic and containerd stores expose different IDs; both preserve the archive tag.
    return manifest[0]['RepoTags'][0]

def edge_configuration(origin):
    # Docker recreates missing bind-mount sources as directories. Keep this
    # non-secret configuration off /run so HTTPS survives a host reboot.
    directory = pathlib.Path('/etc/trulyyou')
    directory.mkdir(mode=0o700, parents=True, exist_ok=True)
    filename = directory / 'Caddyfile'
    filename.write_text(origin+' {\n reverse_proxy 127.0.0.1:4802\n}\n')
    filename.chmod(0o600)
    return filename
provider, bucket, account = sys.argv[1:4]
root = pathlib.Path('/run/trulyyou'); root.mkdir(mode=0o700, exist_ok=True)
def download(name, target):
    if provider == 'aws':
        import boto3
        boto3.client('s3').download_file(bucket, name, str(target))
    elif provider == 'gcp':
        from google.cloud import storage
        storage.Client().bucket(bucket).blob(name).download_to_filename(str(target))
    else:
        from azure.identity import DefaultAzureCredential
        from azure.storage.blob import BlobServiceClient
        blob = BlobServiceClient('https://' + account + '.blob.core.windows.net', credential=DefaultAzureCredential()).get_blob_client(bucket, name)
        with open(target, 'wb') as output: blob.download_blob().readinto(output)
    target.chmod(0o600)
download('bootstrap/environment.json', root/'environment.json')
config = json.loads((root/'environment.json').read_text())
# Docker's env-file is line-oriented: encoded JSON values contain no literal newlines.
if any('\n' in value or '\r' in value for value in config.values()): raise ValueError('Invalid environment')
(root/'environment').write_text('\n'.join(key+'='+value for key,value in config.items())); (root/'environment').chmod(0o600)
download('bootstrap/dashboard.tar', root/'dashboard.tar')
with tarfile.open(root/'dashboard.tar') as archive:
    image_id = archive_image_reference(archive)
subprocess.run(['docker','load','--input',str(root/'dashboard.tar')], check=True, stdout=subprocess.DEVNULL)
subprocess.run(['docker','tag',image_id,'trulyyou-dashboard:installed'],check=True)
(root/'dashboard.tar').unlink()
subprocess.run(['docker','rm','-f','trulyyou-dashboard'], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
subprocess.run(['docker','run','-d','--name','trulyyou-dashboard','--restart','unless-stopped','--network','host','--group-add',str(os.stat('/var/run/docker.sock').st_gid),'--env-file',str(root/'environment'),'-v','/var/run/docker.sock:/var/run/docker.sock','trulyyou-dashboard:installed'], check=True)
caddyfile = edge_configuration(config['PUBLIC_DASHBOARD_ORIGIN'])
subprocess.run(['docker','rm','-f','trulyyou-edge'], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
subprocess.run(['docker','run','-d','--name','trulyyou-edge','--restart','unless-stopped','--network','host','-v',str(caddyfile)+':/etc/caddy/Caddyfile:ro','-v','trulyyou-tls:/data','caddy:2.10.2'], check=True)
(root/'environment.json').unlink(); (root/'environment').unlink()
